<?php
$host='localhost';
$user='root';
$pass="";
$dbname='vtpfinal';

$con=mysqli_connect($host,$user,$pass,$dbname);





?>